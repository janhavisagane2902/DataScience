f=open("Netflix.csv","r")
lang=input("Enter Language: ")
cnt=0
tot=0

for rec in f:
      tot+=1
      if rec.split(',')[1].upper()==lang.upper:()
      cnt+=1


print('total %s movies of the language : %d' %(lang,cnt))
perc=cnt*100/tot
print('Percent of %s movies in the language %.2f%%' %(lang,perc))       	