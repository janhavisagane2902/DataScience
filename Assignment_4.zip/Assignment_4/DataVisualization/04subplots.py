from matplotlib import pyplot as mpl

x=[1,2,3,4,5,6]
y=[1,4,9,16,25,36]
z=[1,8,27,64,125,216]

fig, axes=mpl.subplots(1,2)
axes[0].plot(x,y,'g--')
axes[1].plot(x,z,'r--')
mpl.show()