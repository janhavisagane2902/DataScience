import matplotlib.pyplot as mpl

companies=['Microsoft','Google','Wipro','TCS','Capgemini','Infosys','IBM','Relaince','HCL Technology','Tech Mahindra']
avgsalary=[50000,65000,30000,25000,60000,30000,45000,30000,45000,45000]

mpl.plot(companies,avgsalary,color='red',linestyle='dashdot')
mpl.scatter(companies,avgsalary,color='sky blue'
mpl.xlabel('Companies')
mpl.ylabel('Avg Salary')
mpl.title('Companies over the Glob')
mpl.grid(True)
mpl.show()
