import matplotlib.pyplot as mpl

companies=['Microsoft','Google','Capgemini','IBM','Relaince']
JobsGiven=[50,30,20,15,61]
clr=['red','blue','green','magenta','cyan']

mpl.bar(companies,JobsGiven,color=clr)
mpl.xlabel('Companies')
mpl.ylabel('Jobs Given')

mpl.show()