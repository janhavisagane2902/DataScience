import matplotlib.pyplot as mpl

companies=['Microsoft','Google','Capgemini','IBM','Relaince']
JobsGiven=[50,30,20,15,61]

mpl.pie(JobsGiven,labels=companies)
mpl.title('JOB')
mpl.show()